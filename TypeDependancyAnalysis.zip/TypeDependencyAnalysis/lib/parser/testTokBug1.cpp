/* this is a comment */
int x;
// another comment
double y;
/* a comment */ char z; // another
int /* weird */ v = 2;
string s = "this is a string";
s += 'z';
int w;
s += '\n';
int v;
#endif
//this is a comment with no newline